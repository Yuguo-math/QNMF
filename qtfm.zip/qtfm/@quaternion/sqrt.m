function Y = sqrt(X)
% SQRT   Square root.
% (Quaternion overloading of standard Matlab function.)

% Copyright (c) 2005, 2006 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

narginchk(1, 1), nargoutchk(0, 1)

if isreal(X)
    
    % X is a real quaternion, and we compute the square root of an
    % isomorphic complex number using the standard Matlab square root
    % function, then construct a quaternion with the same axis as the
    % original quaternion.
    
    Y = isoquaternion(sqrt(isocomplex(X)), X);
else
    
    % X is a complex quaternion, and therefore we cannot use the method
    % above for real quaternions, because it is not possible to construct
    % an isomorphic complex number. Therefore we use polar form and halve
    % the argument. Note that the modulus and argument here are complex,
    % so the square root of the modulus is complex.
    
    % Preconstruct a result array of zero quaternions, of the same size as
    % X and with components of the same class.
    
    Y = zerosq(size(X), class(x(X)));
    
    % If the vector part of any element of X is zero, computing its axis
    % will result in an undefined axis warning. We avoid this warning by
    % computing just the square root of the scalar part in these cases.
    % There may be no such cases, or all the elements in X may have
    % undefined axis.
    
    undefined = abs(normq(v(X))) < eps;
    defined   = ~undefined;
        
    % In order to perform the subscripted assignment using the logical 
    % array undefined we have to use subsasgn and substruct because normal
    % indexing does not work here in a class method.
    % See the file 'Implementation notes.txt', item 8, for more details.

    if nnz(undefined) > 0
        % There are some cases of undefined axis.
        U = scalar(subsref(X, substruct('()',  {undefined})));
        Y = subsasgn(Y, substruct('()', {undefined}), quaternion(sqrt(U)));
    end
    
    if nnz(defined) > 0
        % There are some cases where the axis is defined.
        D = subsref(X, substruct('()', {defined}));    
        Y = subsasgn(Y, substruct('()', {defined}), ...
                    sqrt(abs(D)) .* exp(axis(D) .* angle(D) ./ 2));
    end
end

% TODO Consider whether a better algorithm could be devised for the complex
% case based on the Cartesian form. A formula for the complex square root
% is given as eqn 12 on page 17 of:
%
% John H. Mathews,
% 'Basic Complex Variables for Mathematics and Engineering',
% Allyn and Bacon, Boston, 1982. ISBN 0-205-07170-8.
%
% There is a formula given in the following book, which may be worth
% investigation. It is: Y = (1 + X) ./ sqrt(2 .* (1 + X.w)). Notice this
% requires adding 1 to the scalar part, and then dividing by a real value.
% The formula is valid only for unit quaternions, so an adjustment would be
% needed to handle the general case.
%
% Andrew J. Hanson, 'Visualizing quaternions',
% Morgan Kaufmann, 2006, ISBN 0-12-088400-3, Section F2, p452.
%
% A further possibility is Hero or Heron's method, which is a special case
% of Newton's method. This is iterative, but it seems to converge fast even
% for a biquaternion. It may be better than finding the angle and axis.

% $Id: sqrt.m 1048 2020-02-05 19:32:45Z sangwine $
