function F = funm(A,fun)
% Evaluate general matrix function.
% (Quaternion overloading of standard Matlab function.)
% This function is not yet implemented for quaternions but may be
% added at a later date. Please contact the authors of QTFM.

% Copyright (c) 2008 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

help quaternion/funm;
unimplemented(mfilename);

% TODO Implement the function funm.
% $Id: funm.m 1004 2017-11-15 17:14:09Z sangwine $
